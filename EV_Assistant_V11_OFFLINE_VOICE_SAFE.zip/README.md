# EV Assistant V8 Core Stability

V8 fixes the core Android location, weather, radio and voice-media lifecycle.

- Native Android foreground location permission + location service check
- Native device coordinates passed to JavaScript weather engine
- No IP-location fallback for weather accuracy
- Current rain + hourly rain/precipitation analysis
- Rain-stop estimate with uncertainty fallback
- Media3 ExoPlayer for live radio/HLS/progressive streams
- Web audio fallback for supported streams
- Existing voice/wake-word logic preserved
- Android 10 compatible (minSdk 23)

Default identity remains EB / nickname Beli / user Piiitter, with Amlan and custom name options.


## V9 Offline / Zero-Server Core
- Removed cloud AI/API server integration and remote developer config.
- Removed public web/Wikipedia knowledge lookups.
- Removed live weather network calls; location itself remains fully native/local.
- Added native flashlight ON/OFF control.
- Added Android dialer control for any phone number (opens system dialer; no CALL_PHONE permission).
- Added Location ON/settings command using Android system Location Settings.
- Added quick buttons for Flashlight, Dial and Location.
- Internet permission is retained only for optional user-supplied radio streams; the app has no developer backend/API endpoint.
- API credentials previously stored in localStorage are cleared/ignored by the offline build.
